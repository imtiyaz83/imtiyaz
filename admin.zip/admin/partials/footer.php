
<!-- Theme JS -->
<!-- Vendor JS -->
<script src="dist/assets/js/vendor.bundle.js"></script>

<!-- Theme JS -->
<script src="dist/assets/js/theme.bundle.js"></script>
</body>

</html>
