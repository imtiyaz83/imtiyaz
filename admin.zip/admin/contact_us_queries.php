<?php
    require_once "../lib/database.php";
    require_once "partials/header.php";
?>

	<!-- Navbar Section Start -->
	<?php require_once "partials/navigation.php"?>
	<!-- Nav Section End -->

    <?php require_once "partials/right_bar.php"?>

    <?php
        $query = "select id, first_name, last_name, email, mobile, query, created_at from contact_us order by id desc";
        $results = mysqli_query($conn, $query);
    ?>
    
    <!-- Page Content -->
    <main id="main">

        <!-- Breadcrumbs-->
        <div class="bg-white border-bottom py-3 mb-5">
          <div class="container-fluid d-flex justify-content-between align-items-start align-items-md-center flex-column flex-md-row">
            <nav class="mb-0" aria-label="breadcrumb">
              <ol class="breadcrumb m-0">
                <li class="breadcrumb-item"><a href="dashboard.php">Home</a></li>
                  <li class="breadcrumb-item active" aria-current="page">Contact Us Queries</li>
              </ol>
            </nav>
          
          </div>
        </div>        <!-- / Breadcrumbs-->

        <!-- Content-->
        <section class="container-fluid">
        <div class="card-body">

<!-- User Listing Table-->
<div class="table-responsive">
    <table class="table m-0 table-striped">
        <thead>
            <?php
        if (!empty($results)) {
            ?>
            <tr>
                <th>
                    <div class="form-group form-check-custom mb-0 flex-shrink-0">
                        <input type="checkbox" class="form-check-input" id="filter-">
                    </div>
                </th>
                <th>First Name</th>
                <th>Last Name</th>
                <th>Email</th>
                <th>Mobile</th>
                <th>Query</th>
                <th>Created At</th>
            </tr>
        </thead>
        <tbody>
        <?php
            while($row = mysqli_fetch_array($results, MYSQLI_ASSOC)) {
        ?>
            <tr>
                <td>
                    <div class="form-group form-check-custom mb-0">
                        <input type="checkbox" class="form-check-input" id="filter-0">
                    </div>
                </td>
                <td><?php echo !empty($row['first_name']) ? $row['first_name'] : '';?></td>
                <td><?php echo !empty($row['last_name']) ? $row['last_name'] : '';?></td>
                <td><?php echo !empty($row['email']) ? $row['email'] : '';?></td>
                <td><?php echo !empty($row['mobile']) ? $row['mobile'] : '';?></td>
                <td><?php echo !empty($row['query']) ? $row['query'] : '';?></td>
                <td class="text-muted"><?php echo !empty($row['created_at']) ? $row['created_at'] : '';?></td>
            </tr>
        <?php } } else {?> 
            <tr>
                <td colspan="7" align="center">Sorry! No Record Found.</td>
            </tr>
            <?php }?>
        </tbody>
    </table>
</div>    
<!-- /User Listing Table-->
<!--<nav>
    <ul class="pagination justify-content-end mt-3 mb-0">
      <li class="page-item"><a class="page-link" href="#">Previous</a></li>
      <li class="page-item active"><a class="page-link" href="#">1</a></li>
      <li class="page-item"><a class="page-link" href="#">2</a></li>
      <li class="page-item"><a class="page-link" href="#">3</a></li>
      <li class="page-item"><a class="page-link" href="#">Next</a></li>
    </ul>
  </nav>-->
</div>
        </secttion>
        
        <?php require_once "partials/footer_upper.php"?>

    </main>
    <!-- /Page Content -->

    <?php require_once "partials/footer.php"?>

    