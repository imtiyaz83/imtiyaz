<?php
    session_start();
    if (!empty($_SESSION['loginData'])) {
        unset($_SESSION['loginData']);
        session_destroy();
    }
    header("Location: index.php");
    exit(); // Make sure to call exit() after header() to stop further execution
   
?>