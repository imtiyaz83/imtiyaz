<?php require_once "partials/header.php"?>

	<!-- Navbar Section Start -->
	<?php require_once "partials/navigation.php"?>
	<!-- Nav Section End -->

    <?php require_once "partials/right_bar.php"?>
    
    <!-- Page Content -->
    <main id="main">

        <!-- Breadcrumbs-->
        <div class="bg-white border-bottom py-3 mb-5">
          <div class="container-fluid d-flex justify-content-between align-items-start align-items-md-center flex-column flex-md-row">
            <nav class="mb-0" aria-label="breadcrumb">
              <ol class="breadcrumb m-0">
                <li class="breadcrumb-item"><a href="./index.html">Home</a></li>
                  <li class="breadcrumb-item active" aria-current="page">Dashboard</li>
              </ol>
            </nav>
          
          </div>
        </div>        <!-- / Breadcrumbs-->

        <!-- Content-->
        <section class="container-fluid">

        <!-- Page Title-->
        <h2 class="fs-4 mb-2">Welcome, Admin!</h2>
        
        <!--<div class="card mb-4">
            
            <div class="card-body">
                <p>Imtiyaz Khan</p>
            </div>
        </div>-->
        
        <?php require_once "partials/footer_upper.php"?>

    </main>
    <!-- /Page Content -->

    <?php require_once "partials/footer.php"?>

    