<?php
require_once "../lib/database.php";
    // Check if the form is submitted
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $errorMsg = '';
        if (empty($_POST['username'])) {
            $errorMsg .= 'Please enter correct username.<br />';
        }

        if (empty($_POST['password'])) {
            $errorMsg .= 'Please enter your correct password.<br />';
        }
        if (!empty($errorMsg)) {
            $errMsg = 'Please fix the following errors to proceed:<br />';
            $_SESSION['sessErrorMsg'] = $errMsg . $errorMsg;
            header("Location: index.php");
            exit(); // Make sure to call exit() after header() to stop further execution
        }
        $query = "select id, username, password, email from users where username = '".$_POST['username']."' and password = '".$_POST['password']."'";
        $queryExecute = mysqli_query($conn, $query);
        if (!empty($queryExecute->num_rows)) {
            //die('7777');
            $row = $queryExecute -> fetch_array();
            if (!empty($row)) {
                $_SESSION['loginData'] = $row;
                header("Location: dashboard.php");
                exit(); // Make sure to call exit() after header() to stop further execution
            }
            
        } else {
            //die('hererrrr');
            $errMsg = 'Please fix the following errors to proceed:<br />';
            $_SESSION['sessErrorMsg'] = $errMsg . 'Either Username or Password wrong. Please enter correct Username and Password.';
            header("Location: index.php");
            exit();
        }
        // Close statement and connection
        $stmt->close();
        $conn->close();
    }
?>